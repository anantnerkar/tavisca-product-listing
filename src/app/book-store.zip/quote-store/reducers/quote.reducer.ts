import { Quote } from '../../models/quote';
import { QuoteActions, ADD_QUOTE, GET_QUOTES, DELETE_QUOTES, UPDATE_QUOTES, DATA_LOAD, ADD_QUOTE_SUCCESS } from '../actions/quote.actions';

export interface State {
  quote: Quote[];
  added: boolean | null;
  updated: boolean | null;
  deleted: boolean | null;
  loaded: boolean | null;
  message: string | null;
}

export const initialState: State = {
  quote: [],
  message: null,
  added: null,
  updated: null,
  loaded: null,
  deleted:  null
};
export function reducer(state: State = initialState, action: QuoteActions): State {
    switch (action.type) {
        case ADD_QUOTE: {
        console.log('Add quotes', action);
        return {
          ...state
        };
        }
        case GET_QUOTES: {
            console.log('get quotes', action, state);
            return {
                    ...state
            };
      }
        case DELETE_QUOTES: {
            console.log('delete quotes', action);
            return {
                    ...state
            };
        }
      case UPDATE_QUOTES: {
        console.log('update quotes', action);
        return {
                ...state
        };
      }
      case DATA_LOAD: {
        console.log('in data_load', action, state);
        return {
          ...state,
          quote: action.payload,
          message: null,
          loaded: true
        };
      }
      case ADD_QUOTE_SUCCESS: {
        return {
         ...state,
          message: 'The quote is added successfully!',
          added: true
        };
        }
      default: {
        return state;
      }
    }
  }
