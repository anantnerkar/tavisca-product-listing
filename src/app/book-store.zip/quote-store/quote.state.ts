import { Quote } from '../models/quote';
export interface QuoteState {
    readonly quotes: Quote[];
}
